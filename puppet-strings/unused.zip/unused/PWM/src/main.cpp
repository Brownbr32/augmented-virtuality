#include <Arduino.h>
#define STOP 132
#define ON 168
#define PART_ON 110
#define REV 96

const int numVals = 3;
int freqs[numVals] = {96, 168, 156};
int i = 0;


void setup() {
  Serial.begin(9600);
  pinMode(D0, OUTPUT);
  analogWriteFreq(60);
  // put your setup code here, to run once:
}
int inc = 1;
int pwr = 96;
void loop() {
  // for(pwr = 96; pwr <= 168; pwr+=5) {
  //   analogWrite(D0,pwr);
  //   Serial.println(pwr);
  //   delay (500);
  // }
  // for(pwr = 168; pwr >= 96; pwr-=5) {
  //   analogWrite(D0,pwr);
  //   Serial.println(pwr);
  //   delay (500);
  // }
  analogWrite(D0, STOP);
  Serial.println("Stop");
  delay(1500);
  Serial.println(124);
  analogWrite(D0, 124);
  delay(1500);
  analogWrite(D0, STOP);
  Serial.println("Stop");
  delay(1500);
  Serial.println(145);
  analogWrite(D0, 145);
  delay(1500);

  // put your main code here, to run repeatedly:
}