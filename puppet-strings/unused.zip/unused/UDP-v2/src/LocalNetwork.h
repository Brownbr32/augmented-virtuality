#include <ESP8266WiFi.h>



struct LocalNetwork {
    String name = "The Anti-Nexus";
    String pass = "Dape+Vape";
//    String name = "Mr Brown Can Moo";
//    String pass = "C@n y0u?";
    String ip_port;
    unsigned int port = 4210;
    bool connect() {
      
      Serial.print("\nConfiguring access point\n");
      WiFi.begin(this->name, this->pass);
    
      Serial.print("Connecting to ");
      Serial.print(this->name);
      while (WiFi.status() != WL_CONNECTED)
      {
        delay(500);
        Serial.print(".");
      }
      Serial.println();
    
      Serial.print("Connected, IP address: ");
      Serial.println(WiFi.localIP());
      ip_port = WiFi.localIP().toString() + ":" + port;
      
    }
};
