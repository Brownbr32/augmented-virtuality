#include <stdint.h>



template <class DataType>
class Device {
  public:
    char name[10];
    uint8_t pin;
    DataType* val;
    
    Device(char name[10], uint8_t pin, void* val) {
      strncpy(this->name, name,9);
      this->name[9] = 0;
      this->pin  = pin;
      this->val  = (DataType*) val;
    };

    ~Device() {
      Serial.println("Destroying DeviceLL");
    };
};
