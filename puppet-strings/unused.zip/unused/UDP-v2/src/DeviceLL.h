#include <stdint.h>
#include "Device.h"



template <class DataType>
class DeviceLL {
  public:
    DeviceLL<DataType>* next;
    Device<DataType> *device;
    
    DeviceLL(char name[10], uint8_t pin, void* val, void* next = NULL) {
      this->next = (DeviceLL<DataType>*) next;
      this->device = new Device<DataType>(name, pin, val);
    };
    
    DeviceLL(Device<DataType> device, void* next = NULL) {
      this->next = (DeviceLL<DataType>*) next;
      this->device = &device;
    };
    
    DeviceLL(Device<DataType>* device, void* next = NULL) {
      this->next = (DeviceLL<DataType>*) next;
      this->device = device;
    };

    ~DeviceLL() {
      if (this->next != NULL) delete this->next;
      delete this->device;
      Serial.println("Destroying DeviceLL\n");
    };
};
