#include <stdint.h>
#include "DeviceLL.h"



// to do: Type -> DataType



struct DeviceManager {
  private:
    // change template here! *!*
    int glassCeiling = 1023; // only have dutyCycle range of 0-1023 on PWM
    DeviceLL<short>* deviceList;
    
  
  
  public:
    DeviceManager(void* packet) {
      deviceList = new DeviceLL<short>("ESC", D1, packet);
      packet += sizeof(*(deviceList->device->val));
      deviceList = new DeviceLL<short>("servo", D2, packet, (void*) deviceList);
      packet += sizeof(*(deviceList->device->val));
    };

    void print() {
      DeviceLL<short>* tmp = deviceList;
      while (tmp) {
        printf("Device Name: %s\n", tmp->device->name);
        tmp = tmp->next;
      }
    }
    
    unsigned char dataLength() {
      return 4; // *!* fix this!
    };
    
    bool write(bool printEnabled) {
      DeviceLL<short>* tmp = deviceList;
      if(printEnabled) Serial.println("Writing the following values to devices:");
      while (tmp) {
        if(printEnabled) Serial.printf("%s:\t%d\n", tmp->device->name,1023-withGlassCeiling(tmp->device->val));
        analogWrite(tmp->device->pin, withGlassCeiling(tmp->device->val));
        tmp = tmp->next;
      }
    };

    int withGlassCeiling(short* val) {
      return ((unsigned int) *val > glassCeiling) ? glassCeiling : (unsigned int) *val;
    }

    ~DeviceManager() {
        delete deviceList;
        Serial.println("Destroying DeviceManager");
    };
};
