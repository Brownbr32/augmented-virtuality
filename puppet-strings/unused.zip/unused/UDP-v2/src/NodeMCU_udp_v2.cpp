#include <arduino.h>
#include <WiFiUdp.h>
#include "LocalNetwork.h"
#include "DeviceManager.h"



DeviceManager* devices = NULL;

WiFiUDP Udp;
unsigned const char packetBytes = 256;
unsigned long packet[256/4];


// todo: destructor correction

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);

  delay(1000);
  
  devices = new DeviceManager(packet);  // created:
                                          // ESC
                                          // servo
                                          // new device
  Serial.println("\nprinting devices:");
  devices->print();                     // will print:
                                          // new device
                                          // servo
                                          // ESC



  LocalNetwork localNetwork;
  localNetwork.connect();
  Udp.begin(localNetwork.port);
  
  Serial.print("send datagrams to: ");
  Serial.println(localNetwork.ip_port);
  Serial.println("\n\n");
}



int   packetSize;
int   len;
bool printEnabled = true;

void loop() {
  packetSize = Udp.parsePacket();
  if (packetSize) {
    // packet handling
    Serial.printf("Received %d bytes from %s, port %d\n", packetSize, Udp.remoteIP().toString().c_str(), Udp.remotePort());
    len = Udp.read((char*)packet, 255);

    // device writing
    devices->write(printEnabled);
    
    Serial.println("");
  }
}
