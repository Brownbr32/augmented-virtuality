/******************************************************************************
 * Copyright 2013-2014 Espressif Systems (Wuxi)
 *
 * FileName: user_main.c
 *
 * Description: entry file of user application
 *
 * Modification history:
 *     2015/7/3, v1.0 create this file.
*******************************************************************************/

#include "../include/config.h"
#include "esp_common.h"
#include "hw_timer.h"
#include "gpio.h"

/******************************************************************************
 * FunctionName : user_rf_cal_sector_set
 * Description  : SDK just reversed 4 sectors, used for rf init data and paramters.
 *                We add this function to force users to set rf cal sector, since
 *                we don't know which sector is free in user's application.
 *                sector map for last several sectors : ABCCC
 *                A : rf cal
 *                B : rf init data
 *                C : sdk parameters
 * Parameters   : none
 * Returns      : rf cal sector
*******************************************************************************/
uint32 user_rf_cal_sector_set(void)
{
    flash_size_map size_map = system_get_flash_size_map();
    uint32 rf_cal_sec = 0;

    switch (size_map) {
        case FLASH_SIZE_4M_MAP_256_256:
            rf_cal_sec = 128 - 5;
            break;

        case FLASH_SIZE_8M_MAP_512_512:
            rf_cal_sec = 256 - 5;
            break;

        case FLASH_SIZE_16M_MAP_512_512:
        case FLASH_SIZE_16M_MAP_1024_1024:
            rf_cal_sec = 512 - 5;
            break;

        case FLASH_SIZE_32M_MAP_512_512:
        case FLASH_SIZE_32M_MAP_1024_1024:
            rf_cal_sec = 1024 - 5;
            break;
        case FLASH_SIZE_64M_MAP_1024_1024:
            rf_cal_sec = 2048 - 5;
            break;
        case FLASH_SIZE_128M_MAP_1024_1024:
            rf_cal_sec = 4096 - 5;
            break;
        default:
            rf_cal_sec = 0;
            break;
    }

    return rf_cal_sec;
}

bool output = 0;
void flip() {
	GPIO_OUTPUT_SET(GPIO_Pin_4,output);
	gpio16_output_set(output);
	output = !output;
}

int escDutyCycle = 50;
bool escOn = false;
struct pwm_pin {
	unsigned long pin;
	int period;
	int freq;
	int duty;
	int rem;
	bool on;
} ESC, SERVO;

void initVars() {
	int micros = 1000000;
	SERVO.freq = 50;
	ESC.pin 	= GPIO_Pin_2;
	SERVO.pin = GPIO_Pin_5;
	ESC.period = 50;
	SERVO.period = micros/SERVO.freq;
	ESC.duty = 10;
	SERVO.duty = SERVO.rem =  SERVO.period/4*3;
	ESC.on = true;
	SERVO.on = false;

	
	GPIO_AS_OUTPUT(ESC.pin);
	GPIO_AS_OUTPUT(SERVO.pin);
	GPIO_OUTPUT_SET(ESC.pin,0);
	GPIO_OUTPUT_SET(SERVO.pin,0);
}

void servo() {
	GPIO_OUTPUT_SET(SERVO.pin,SERVO.on);
	SERVO.duty = SERVO.rem = SERVO.period - SERVO.duty;
	SERVO.on = !SERVO.on;
};

void esc() {
	GPIO_OUTPUT_SET(ESC.pin,ESC.on);
	ESC.duty = ESC.period - ESC.duty;
	ESC.on = !ESC.on;
	if(SERVO.rem <= 0) servo();
	hw_timer_arm(ESC.duty,1);
	SERVO.rem -= ESC.duty + 5;
}



void user_init(void)
{
	initVars();
	gpio16_output_conf();
	hw_timer_init();
	hw_timer_set_func(esc);
	esc();
	while (true) {
	};
}